#!/bin/bash

# URLs of the .txt files
FILE1_URL="https://raw.githubusercontent.com/yourusername/yourrepository/branch/path/to/file1.txt"
FILE2_URL="https://raw.githubusercontent.com/yourusername/yourrepository/branch/path/to/file2.txt"

# Interval how long each file is displayed before switching
INTERVAL=1

while true; do
    clear
    curl -s $FILE1_URL
    sleep $INTERVAL
    clear
    curl -s $FILE2_URL
    sleep $INTERVAL
done
